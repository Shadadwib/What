// وظيفة البحث عن عقارات
function searchProperties() {
  // الحصول على قيم البحث من نموذج البحث
  const location = document.getElementById('location').value;
  const budget = document.getElementById('budget').value;
  const rooms = document.getElementById('rooms').value;

  // إرسال طلب بحث إلى خادم
// ... (وظائف البحث عن العقارات)

// إنشاء اتصال Socket.io مع خادم الدردشة
const socket = io('http://localhost:3000'); // استبدل localhost:3000 بعنوان خادم الدردشة

// إرسال رسالة من المستخدم إلى الذكاء الاصطناعي
const chatForm = document.getElementById('chat-form');
chatForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const message = document.getElementById('chat-input').value;
  socket.emit('chat message', message);

  const chatMessage = document.createElement('div');
  chatMessage.classList.add('chat-message', 'chat-message-user');
  chatMessage.textContent = message;
  document.getElementById('chat-box').appendChild(chatMessage);

  document.getElementById('chat-input').value = '';
});

// استقبال رسالة من الذكاء الاصطناعي
socket.on('chat message', function(message) {
  const chatMessage = document.createElement('div');
  chatMessage.classList.add('chat-message', 'chat-message-ai');
  chatMessage.textContent = message;
  document.getElementById('chat-box').appendChild(chatMessage);
});
